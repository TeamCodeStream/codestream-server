// mongo configuration

'use strict';

// mongo url can come from either a raw supplied url or from individual components,
// where authentication with user and password may or not be relevant
let MongoUrl = process.env.CS_OUTBOUND_EMAIL_MONGO_URL;
if (!MongoUrl) {
	if(process.env.CS_OUTBOUND_EMAIL_MONGO_USER) {
		MongoUrl = `mongodb://${process.env.CS_OUTBOUND_EMAIL_MONGO_USER}:${process.env.CS_OUTBOUND_EMAIL_MONGO_PASS}@${process.env.CS_OUTBOUND_EMAIL_MONGO_HOST}:${process.env.CS_OUTBOUND_EMAIL_MONGO_PORT}/${process.env.CS_OUTBOUND_EMAIL_MONGO_DATABASE}`;
	}
	else {
		MongoUrl = `mongodb://${process.env.CS_OUTBOUND_EMAIL_MONGO_HOST}:${process.env.CS_OUTBOUND_EMAIL_MONGO_PORT}/${process.env.CS_OUTBOUND_EMAIL_MONGO_DATABASE}`;
	}
}

module.exports = {
	host: process.env.CS_OUTBOUND_EMAIL_MONGO_HOST,
	port: process.env.CS_OUTBOUND_EMAIL_MONGO_PORT,
	database: process.env.CS_OUTBOUND_EMAIL_MONGO_DATABASE,
	user: process.env.CS_OUTBOUND_EMAIL_MONGO_USER,
	pass: process.env.CS_OUTBOUND_EMAIL_MONGO_PASS,
	url: MongoUrl,
	hintsRequired: true
};
