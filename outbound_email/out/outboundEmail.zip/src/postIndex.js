'use strict';

module.exports = {
	// stolen from api server, kind of a hack that this code is duplicated
	bySeqNum: {
		teamId: 1,
		streamId: 1,
		seqNum: 1
	}
};
